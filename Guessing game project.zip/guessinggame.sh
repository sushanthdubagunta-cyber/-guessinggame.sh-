#!/usr/bin/env bash
# File: guessinggame.sh

function ask_guess {
    echo "How many files are in the current directory?"
    read guess
}

file_count=$(ls -1 | wc -l)
guess=-1

echo "Welcome to the Guessing Game!"
echo "---------------------------------"

while [[ $guess -ne $file_count ]]
do
    ask_guess
    if [[ $guess -lt $file_count ]]
    then
        echo "Too low! Try again."
    elif [[ $guess -gt $file_count ]]
    then
        echo "Too high! Try again."
    else
        echo "Congratulations! You guessed correctly."
        echo "There are indeed $file_count files in the directory."
        break
    fi
    echo ""
done
